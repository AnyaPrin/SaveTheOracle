Save The Oracle version 1.1
(minfilia.1.1.py)


「箱入り娘ゲーム」に見せかけたFF14ヨシダ信者向けのスライディングパズルゲーム。 
”The Oracle” を導き外へ脱出させることが目的と見せかけて
ヨシPの有難いお言葉を聞くことが目的です。

windows10 環境、python とpygame が必要です。



操作方法；
マウスドラッグでブロックを移動



動作環境：
Windows 10
Python 3.8 以降
pygame 2.x



インストール・起動方法：
	１．Pythonとpygameをインストールしてください。

	　pip install pygame

	２．解凍したフォルダ内にある`Minifilia.1.1.py` を実行してください

	　python Minifilia.1.1.py



ディレクトリ構造：
<Minifilia>
	<minfilia.1.1>
		<images>
		<souds>
		<fonts>
		minfilia.1.1.py



素材・著作権について：
ゲーム内画像はファイナルファンタジーXIVゲーム内で撮影したものを使用しています。
効果音としてWindows 10のシステム音を利用しています。
本作は非営利・個人利用のファンゲームです。商用利用・二次配布は禁止します。



著作権表示：
© SQUARE ENIX
Windowsシステム音の著作権はMicrosoftに帰属します。



免責事項：
本作は個人による非公式ファン作品であり、スクウェア・エニックスおよびファイナルファンタジーXIV運営とは一切関係ありません。

